<?php

namespace Modules\Transfer\Http\Controllers;

use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Http\Request;
use Modules\Transfer\Entities\TransferRequest;
use Modules\Transfer\Entities\TransferRequestItem;
use Modules\Product\Entities\Warehouse;
use Modules\Product\Entities\Product;
use Modules\Mutation\Entities\Mutation;
use Carbon\Carbon;

class TransferController extends Controller
{
    public function index()
    {
        abort_if(Gate::denies('access_transfers'), 403);

        $transfers = TransferRequest::with(['fromWarehouse', 'toWarehouse', 'items'])->latest()->get();
        return view('transfer::index', compact('transfers'));
    }

    public function create()
    {
        abort_if(Gate::denies('create_transfers'), 403);

        $warehouses = Warehouse::where('branch_id', session('active_branch'))->get();
        $products = Product::all();

        return view('transfer::create', compact('warehouses', 'products'));
    }

    public function store(Request $request)
    {
        abort_if(Gate::denies('create_transfers'), 403);

        $request->validate([
            'reference' => 'required|string|max:255|unique:transfer_requests,reference',
            'date' => 'required|date',
            'from_warehouse_id' => 'required|exists:warehouses,id',
            'to_branch_id' => 'required|exists:branches,id|different:' . session('active_branch'),
            'product_ids' => 'required|array',
            'quantities' => 'required|array',
        ]);

        DB::transaction(function () use ($request) {
            $transfer = TransferRequest::create([
                'reference' => $request->reference,
                'date' => $request->date,
                'from_warehouse_id' => $request->from_warehouse_id,
                'to_branch_id' => $request->to_branch_id, // ✅ Ganti dari to_warehouse_id
                'note' => $request->note,
                'status' => 'pending',
                'branch_id' => session('active_branch'),
                'created_by' => auth()->id(),
            ]);

            foreach ($request->product_ids as $key => $product_id) {
                TransferRequestItem::create([
                    'transfer_request_id' => $transfer->id,
                    'product_id' => $product_id,
                    'quantity' => $request->quantities[$key],
                ]);

                // Insert mutation OUT dari gudang asal
                $prev = Mutation::where('product_id', $product_id)
                    ->where('warehouse_id', $request->from_warehouse_id)
                    ->latest()->first();

                Mutation::create([
                    'reference' => $request->reference,
                    'date' => $request->date,
                    'mutation_type' => 'Transfer',
                    'note' => 'Auto OUT from Transfer #' . $request->reference,
                    'warehouse_id' => $request->from_warehouse_id,
                    'product_id' => $product_id,
                    'stock_early' => $prev ? $prev->stock_last : 0,
                    'stock_in' => 0,
                    'stock_out' => $request->quantities[$key],
                    'stock_last' => ($prev ? $prev->stock_last : 0) - $request->quantities[$key],
                ]);
            }
        });

        toast('Transfer created successfully', 'success');
        return redirect()->route('transfers.index');
    }

    public function show(TransferRequest $transfer)
    {
        return view('transfer::show', compact('transfer'));
    }



    public function confirm(Request $request, TransferRequest $transfer)
    {
        abort_if(Gate::denies('confirm_transfers'), 403);

        $request->validate([
            'to_warehouse_id' => 'required|exists:warehouses,id',
        ]);

        // Pastikan hanya cabang tujuan yang bisa konfirmasi
        if ($transfer->to_branch_id != session('active_branch')) {
            abort(403, 'Unauthorized to confirm this transfer');
        }

        DB::transaction(function () use ($transfer, $request) {
            foreach ($transfer->items as $item) {
                $prev = Mutation::where('product_id', $item->product_id)
                    ->where('warehouse_id', $request->to_warehouse_id)
                    ->latest()->first();

                Mutation::create([
                    'reference' => $transfer->reference,
                    'date' => now(),
                    'mutation_type' => 'Transfer',
                    'note' => 'Auto IN from confirmed Transfer #' . $transfer->reference,
                    'warehouse_id' => $request->to_warehouse_id,
                    'product_id' => $item->product_id,
                    'stock_early' => $prev ? $prev->stock_last : 0,
                    'stock_in' => $item->quantity,
                    'stock_out' => 0,
                    'stock_last' => ($prev ? $prev->stock_last : 0) + $item->quantity,
                ]);
            }

            $transfer->update([
                'status' => 'confirmed',
                'to_warehouse_id' => $request->to_warehouse_id, // isi di sini
                'confirmed_by' => auth()->id(),
                'confirmed_at' => Carbon::now(),
            ]);
        });

        toast('Transfer confirmed and stock updated', 'success');
        return redirect()->route('transfers.index');
    }

    public function storeConfirmation(Request $request, TransferRequest $transfer)
    {
        abort_if(Gate::denies('confirm_transfers'), 403);

        // Pastikan hanya cabang tujuan yang bisa konfirmasi
        if ($transfer->to_branch_id != session('active_branch')) {
            abort(403, 'Unauthorized');
        }

        $request->validate([
            'to_warehouse_id' => 'required|exists:warehouses,id',
            'delivery_proof' => 'required|file|mimes:jpg,jpeg,png,pdf|max:2048',
        ]);

        DB::transaction(function () use ($request, $transfer) {
            // Simpan file bukti
            $path = $request->file('delivery_proof')->store('public/transfer_proofs');
            $filename = str_replace('public/', 'storage/', $path); // agar bisa dipakai di <img src>

            // Update status dan gudang tujuan
            $transfer->update([
                'to_warehouse_id' => $request->to_warehouse_id,
                'delivery_proof_path' => $filename,
                'status' => 'confirmed',
                'confirmed_by' => auth()->id(),
                'confirmed_at' => now(),
            ]);

            // Buat log mutasi masuk (stok IN)
            foreach ($transfer->items as $item) {
                $prev = \Modules\Mutation\Entities\Mutation::where('product_id', $item->product_id)
                    ->where('warehouse_id', $request->to_warehouse_id)
                    ->latest()->first();

                \Modules\Mutation\Entities\Mutation::create([
                    'reference' => $transfer->reference,
                    'date' => now(),
                    'mutation_type' => 'Transfer',
                    'note' => 'Auto IN from confirmed Transfer #' . $transfer->reference,
                    'warehouse_id' => $request->to_warehouse_id,
                    'product_id' => $item->product_id,
                    'stock_early' => $prev ? $prev->stock_last : 0,
                    'stock_in' => $item->quantity,
                    'stock_out' => 0,
                    'stock_last' => ($prev ? $prev->stock_last : 0) + $item->quantity,
                ]);
            }
        });

        toast('Transfer confirmed successfully', 'success');
        return redirect()->route('transfers.index');
    }


}
