@can('confirm_transfers')
    <a href="{{ route('transfers.confirm', $data->id) }}" class="btn btn-sm btn-success">
        <i class="bi bi-box-arrow-in-down"></i> Confirm
    </a>
@endcan
@can('show_transfers')
    <a href="{{ route('transfers.show', $data->id) }}" class="btn btn-sm btn-primary">
        <i class="bi bi-eye"></i> Detail
    </a>
@endcan
@can('delete_transfers')
    <button id="delete" class="btn btn-danger btn-sm" onclick="
        event.preventDefault();
        if (confirm('Are you sure? It will delete the data permanently!')) {
        document.getElementById('destroy{{ $data->id }}').submit()
        }
        ">
        <i class="bi bi-trash"></i>
        <form id="destroy{{ $data->id }}" class="d-none" action="{{ route('mutations.destroy', $data->id) }}" method="POST">
            @csrf
            @method('delete')
        </form>
    </button>
@endcan
