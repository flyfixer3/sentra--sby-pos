@extends('layouts.app')

@section('title', 'Detail Transfer')

@section('content')
<div class="container">
    <h4>Transfer #{{ $transfer->reference }}</h4>
    <p><strong>Date:</strong> {{ $transfer->date }}</p>
    <p><strong>From:</strong> {{ $transfer->fromWarehouse->warehouse_name }}</p>
    <p><strong>To Branch:</strong> {{ $transfer->toBranch->name }}</p>
    <p><strong>Status:</strong> {{ ucfirst($transfer->status) }}</p>

    <hr>

    <h5>Items</h5>
    <ul>
        @foreach ($transfer->items as $item)
            <li>{{ $item->product->name }} — {{ $item->quantity }}</li>
        @endforeach
    </ul>

    @if ($transfer->status == 'pending' && session('active_branch') == $transfer->to_branch_id)
        <a href="{{ route('transfers.confirm', $transfer->id) }}" class="btn btn-success">
            Konfirmasi Transfer
        </a>
    @endif
</div>
@endsection
