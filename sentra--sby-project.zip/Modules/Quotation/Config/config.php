<?php

return [
    'name' => 'Quotation'
];
