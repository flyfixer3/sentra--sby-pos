<?php

return [
    'name' => 'Setting'
];
