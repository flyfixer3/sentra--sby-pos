<?php

return [
    'name' => 'PurchaseDelivery'
];
