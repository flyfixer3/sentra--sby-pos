<?php

namespace Modules\Product\DataTables;

use Modules\Product\Entities\Warehouse;
use Yajra\DataTables\Html\Button;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Services\DataTable;

class WarehouseDataTable extends DataTable
{
    public function dataTable($query) {
        return datatables()
            ->eloquent($query)
            ->editColumn('warehouse_name', function ($data) {
                return $data->is_main
                    ? $data->warehouse_name . ' <span class="badge badge-success">Main</span>'
                    : $data->warehouse_name;
            })
            ->rawColumns(['warehouse_name', 'action'])
            ->addColumn('action', function ($data) {
                return view('product::warehouses.partials.actions', compact('data'));
            });
    }

    public function query(Warehouse $model) {
        return $model->newQuery()->select([
            'id', 'warehouse_code', 'warehouse_name', 'is_main', 'created_at'
        ]);
    }

    public function html() {
        return $this->builder()
            ->setTableId('product_warehouses-table')
            ->columns($this->getColumns())
            ->minifiedAjax()
            ->dom("<'row'<'col-md-3'l><'col-md-5 mb-2'B><'col-md-4'f>>" .
                  "tr" .
                  "<'row'<'col-md-5'i><'col-md-7 mt-2'p>>")
            ->orderBy(3)
            ->buttons(
                Button::make('excel')->text('<i class="bi bi-file-earmark-excel-fill"></i> Excel'),
                Button::make('print')->text('<i class="bi bi-printer-fill"></i> Print'),
                Button::make('reset')->text('<i class="bi bi-x-circle"></i> Reset'),
                Button::make('reload')->text('<i class="bi bi-arrow-repeat"></i> Reload')
            );
    }

    protected function getColumns() {
        return [
            Column::computed('warehouse_code')
                ->title('Warehouse Code')
                ->className('text-center'),

            Column::computed('warehouse_name')
                ->title('Warehouse Name')
                ->className('text-center'),

            Column::computed('action')
                ->exportable(false)
                ->printable(false)
                ->addClass('text-center'),

            Column::make('is_main')->visible(false),
            Column::make('created_at')->visible(false),
        ];
    }

    protected function filename() {
        return 'Warehouses_' . date('YmdHis');
    }
}
