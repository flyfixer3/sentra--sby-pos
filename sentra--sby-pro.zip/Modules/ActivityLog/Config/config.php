<?php

return [
    'name' => 'ActivityLog'
];
